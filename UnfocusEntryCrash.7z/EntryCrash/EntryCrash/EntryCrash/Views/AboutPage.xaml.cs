﻿using System;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace EntryCrash.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AboutPage : ContentPage
    {
        public AboutPage()
        {
            InitializeComponent();
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();

            if(entry.Focus() == false)
            {
                await Task.Delay(300).ContinueWith(t =>
                {
                    Device.BeginInvokeOnMainThread(() => entry.Focus());
                });
            }
        }
    }
}